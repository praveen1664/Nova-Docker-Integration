============
Installation
============

At the command line::

    $ pip install nova-docker

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv nova-docker
    $ pip install nova-docker